package sh.calaba.org.codehaus.jackson.map.ser;

/**
 * @deprecated Since 1.9 use {@link sh.calaba.org.codehaus.jackson.map.ser.std.StdJdkSerializers}
 */
@Deprecated
public class JdkSerializers
    extends sh.calaba.org.codehaus.jackson.map.ser.std.StdJdkSerializers
{

}
